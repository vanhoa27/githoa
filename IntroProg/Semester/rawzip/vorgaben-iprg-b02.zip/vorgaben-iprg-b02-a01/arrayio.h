/*
 * Diese Datei soll nicht verändert werden.
 */
int read_array_from_file(int array[], size_t size, char *filename);
void print_array(int array[], int len);
