void fill_array_randomly(int array[], int len, int max_value);
void fill_array_deterministicly(int array[], int len, int max_value);
void print_array(int array[], int len);

int check_equality_of_arrays(int* array_1, int* array_2, int len);
void copy_array_elements(int* destination, int* source, int len);
void start_timer();
double end_timer();
int get_value_one();
